package com.slimik.limilium.init;

import com.slimik.limilium.items.CyanQuartz;
import com.slimik.limilium.items.IntegratedCircuit;
import com.slimik.limilium.items.PolishedCyanQuartz;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class LimiliumModItems {
    public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, "limilium");

    public static final RegistryObject<Item> DIODE_BLOCK_ITEM = block(LimiliumModBlocks.DIODE_BLOCK);

    public static final RegistryObject<Item> GOLDEN_RESISTOR_BLOCK_ITEM = block(LimiliumModBlocks.GOLDEN_RESISTOR_BLOCK);

    public static final RegistryObject<Item> IRON_RESISTOR_BLOCK_ITEM = block(LimiliumModBlocks.IRON_RESISTOR_BLOCK);

    public static final RegistryObject<Item> CERAMIC_RESISTOR_BLOCK_ITEM = block(LimiliumModBlocks.CERAMIC_RESISTOR_BLOCK);

    public static final RegistryObject<Item> GLASS_RESISTOR_BLOCK_ITEM = block(LimiliumModBlocks.GLASS_RESISTOR_BLOCK);

    public static final RegistryObject<Item> CROSSROAD_BLOCK_ITEM = block(LimiliumModBlocks.CROSSROAD_BLOCK);

    public static final RegistryObject<Item> CONJUNCTOR_BLOCK_ITEM = block(LimiliumModBlocks.CONJUNCTOR_BLOCK);

    public static final RegistryObject<Item> DISJUNCTOR_BLOCK_ITEM = block(LimiliumModBlocks.DISJUNCTOR_BLOCK);

    public static final RegistryObject<Item> EXCLUSIVE_DISJUNCTOR_BLOCK_ITEM = block(LimiliumModBlocks.EXCLUSIVE_DISJUNCTOR_BLOCK);

    public static final RegistryObject<Item> INVERTER_BLOCK_ITEM = block(LimiliumModBlocks.INVERTER_BLOCK);

    public static final RegistryObject<Item> METRONOME_BLOCK_ITEM = block(LimiliumModBlocks.METRONOME_BLOCK);

    public static final RegistryObject<Item> CYAN_QUARTZ = REGISTRY.register("cyan_quartz", () -> new CyanQuartz());

    public static final RegistryObject<Item> POLISHED_CYAN_QUARTZ = REGISTRY.register("polished_cyan_quartz", () -> new PolishedCyanQuartz());

    public static final RegistryObject<Item> INTEGRATED_CIRCUIT = REGISTRY.register("integrated_circuit", () -> new IntegratedCircuit());

    private static RegistryObject<Item> block(RegistryObject<Block> block) {
        return REGISTRY.register(block.getId().getPath(), () -> new BlockItem((Block)block.get(), new Item.Properties()));
    }
}
