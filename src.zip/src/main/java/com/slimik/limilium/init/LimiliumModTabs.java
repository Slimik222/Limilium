package com.slimik.limilium.init;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.registries.DeferredRegister;

@EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class LimiliumModTabs {
    public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, "limilium");

    @SubscribeEvent
    public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
        if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
            tabData.accept((ItemLike)((Block)LimiliumModBlocks.INVERTER_BLOCK.get()).asItem());
            tabData.accept((ItemLike)((Block)LimiliumModBlocks.CONJUNCTOR_BLOCK.get()).asItem());
            tabData.accept((ItemLike)((Block)LimiliumModBlocks.DIODE_BLOCK.get()).asItem());
            tabData.accept((ItemLike)((Block)LimiliumModBlocks.GOLDEN_RESISTOR_BLOCK.get()).asItem());
            tabData.accept((ItemLike)((Block)LimiliumModBlocks.IRON_RESISTOR_BLOCK.get()).asItem());
            tabData.accept((ItemLike)((Block)LimiliumModBlocks.CERAMIC_RESISTOR_BLOCK.get()).asItem());
            tabData.accept((ItemLike)((Block)LimiliumModBlocks.GLASS_RESISTOR_BLOCK.get()).asItem());
            tabData.accept((ItemLike)((Block)LimiliumModBlocks.DISJUNCTOR_BLOCK.get()).asItem());
            //tabData.accept((ItemLike)((Block)LimiliumModBlocks.EXCLUSIVE_DISJUNCTOR_BLOCK.get()).asItem());
            tabData.accept((ItemLike)((Block)LimiliumModBlocks.CROSSROAD_BLOCK.get()).asItem());
            //tabData.accept((ItemLike)((Block)LimiliumModBlocks.METRONOME_BLOCK.get()).asItem());
        } else
        if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            tabData.accept((ItemLike)LimiliumModItems.CYAN_QUARTZ.get());
            tabData.accept((ItemLike)LimiliumModItems.POLISHED_CYAN_QUARTZ.get());
            tabData.accept((ItemLike)LimiliumModItems.INTEGRATED_CIRCUIT.get());
        }
    }
}